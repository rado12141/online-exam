 <style>
 .footeroption{background:#202633;color:#fff;text-align:center;padding:20px;font-family: "Times New Roman", Times, serif;}
 </style>
 
</section>
<section class="footeroption">
		<h2><?php echo "Dept. of Computer Science & Engineering, JUST"; ?></h2>
	</section>
</div>
</body>
</html>